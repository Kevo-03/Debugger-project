#include "DebugHdr.h"
int main()
{
    int a, b;
    b=0;
    a=1;
    while(b<10)
    {
        a=a+b;
        b=b+1;
    }
    return 0;
}